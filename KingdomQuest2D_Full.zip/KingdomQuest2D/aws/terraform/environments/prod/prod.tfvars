# =============================================================================
# Kingdom Quest 2D — Production Environment Variables
# terraform apply -var-file="prod.tfvars"
# NEVER commit db_password to version control — use TF_VAR_db_password env var.
# =============================================================================

environment        = "prod"
aws_region         = "us-east-1"
domain_name        = "kingdomquest2d.com"

# Networking
vpc_cidr            = "10.0.0.0/16"
availability_zones  = ["us-east-1a", "us-east-1b", "us-east-1c"]

# ACM cert ARN (must be in us-east-1 for CloudFront)
acm_certificate_arn = ""   # Fill in after running: aws acm request-certificate

# Database — prod uses larger instance, Multi-AZ on by default in module
db_instance_class = "db.r6g.large"
db_username       = "kq2d_admin"
# db_password     → set via: export TF_VAR_db_password="..."

# Cache
cache_node_type = "cache.r6g.large"

# ECS API — prod: 1 vCPU / 2 GB, 2 → 10 replicas
api_cpu           = 1024
api_memory        = 2048
api_desired_count = 2
api_min_count     = 2
api_max_count     = 20

# Set to your ECR image after first docker build + push
api_docker_image = "ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/kq2d-prod-api:latest"

# Cognito
cognito_callback_urls = [
  "https://kingdomquest2d.com/auth/callback",
  "https://www.kingdomquest2d.com/auth/callback"
]

# Monitoring
alert_email = "ops@kingdomquest2d.com"
